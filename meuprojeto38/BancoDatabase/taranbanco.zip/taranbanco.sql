-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29/07/2024 às 02:01
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `taranbanco`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add Cadastro', 7, 'add_cadastro'),
(26, 'Can change Cadastro', 7, 'change_cadastro'),
(27, 'Can delete Cadastro', 7, 'delete_cadastro'),
(28, 'Can view Cadastro', 7, 'view_cadastro'),
(29, 'Can add Filme', 8, 'add_filme'),
(30, 'Can change Filme', 8, 'change_filme'),
(31, 'Can delete Filme', 8, 'delete_filme'),
(32, 'Can view Filme', 8, 'view_filme'),
(33, 'Can add Perfil', 9, 'add_profile'),
(34, 'Can change Perfil', 9, 'change_profile'),
(35, 'Can delete Perfil', 9, 'delete_profile'),
(36, 'Can view Perfil', 9, 'view_profile'),
(37, 'Can add Filme do Usuário', 10, 'add_userfilme'),
(38, 'Can change Filme do Usuário', 10, 'change_userfilme'),
(39, 'Can delete Filme do Usuário', 10, 'delete_userfilme'),
(40, 'Can view Filme do Usuário', 10, 'view_userfilme'),
(41, 'Can add perfil', 11, 'add_perfil'),
(42, 'Can change perfil', 11, 'change_perfil'),
(43, 'Can delete perfil', 11, 'delete_perfil'),
(44, 'Can view perfil', 11, 'view_perfil');

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$720000$q7gHodz2oO9YhaTFgwM9t7$Tw2CkXMpOlLUgfHVxwsF06dy36gNstc6tgYgE6iQTWE=', '2024-07-26 04:08:34.808261', 0, 'lalala2', '', '', 'lalala2@denv.com', 0, 1, '2024-07-24 02:11:56.783185'),
(2, 'pbkdf2_sha256$720000$TEmPy5Ix0ed8dKLjZBmzC2$I6Z90JxckxlZB6q1lAhNPzTvq1dq/6sDrdvbvkphchI=', NULL, 0, 'lalala3', '', '', 'lalala3@denv.com', 0, 1, '2024-07-24 14:58:17.387571'),
(3, 'pbkdf2_sha256$720000$vGt0ovVk99VdVtOlsQZIl4$VPzmSkMaEK64tazSaUWKC1Rn6bXI2QKf2UxEPHlv5p0=', '2024-07-25 14:23:50.763323', 0, 'lalala36', '', '', 'lalala36@denv.com', 0, 1, '2024-07-24 15:49:40.660634'),
(4, 'pbkdf2_sha256$720000$ywOE9Vvez30wQG0qpoF7oC$UWasf2IlCWqHNij9SI+78xpV6xRcoDSaGmpuWlefbGU=', '2024-07-24 18:46:17.666500', 0, 'ganga', '', '', 'ganga@ganga.com', 0, 1, '2024-07-24 17:39:07.339862'),
(5, 'pbkdf2_sha256$720000$QIEt8y1oDPoVsJLTcwMap1$LKpgubiqH9ENTzxvnC0jp55eNalGhIZWY5WdhbHBD4M=', '2024-07-24 20:42:15.280751', 0, 'refina', '', '', 'refina32@refina32.com', 0, 1, '2024-07-24 19:09:36.284068'),
(6, 'pbkdf2_sha256$720000$zYGZyAGSR0IorAgKzDVA3s$Mfp5cS95Ppk4f+1VM8BCEG8K9UO7Kg66leyI+Cm3Zz0=', '2024-07-24 20:45:01.730513', 0, 'gggggggggg', '', '', '', 0, 1, '2024-07-24 20:44:44.318950'),
(7, 'pbkdf2_sha256$720000$L4w5Fgq6wg6kXOvuevu5Fx$A9r85u9Uw5z8z/ktCPP4MzkHDxWXV6oPh9E8V1bRqX0=', '2024-07-24 22:13:08.256120', 0, 'zzzzzzzzzzzzz', '', '', '', 0, 1, '2024-07-24 21:03:14.545201'),
(8, 'pbkdf2_sha256$720000$oINEcY4vOXKdDLOQZ7Q8pI$eg0VrqrfCmENe2WFtuYNxe28KgDNsHyG7CtHhJvWcic=', '2024-07-25 10:28:10.282157', 0, 'lalala34', '', '', 'lalala34@denv.com', 0, 1, '2024-07-25 10:27:50.429669'),
(9, 'pbkdf2_sha256$720000$pGI8BNnrbn0HfuVTLqHaKt$pGmP3/4Zu4oq4TBqopG+JVdxVb/7HZJ1HyhkU2uI++s=', '2024-07-25 17:38:37.778051', 0, 'lalala3lalala3', '', '', 'lalala3@denv.com', 0, 1, '2024-07-25 14:24:24.990759'),
(10, 'pbkdf2_sha256$720000$1jSY4PWn8W0nQpVNnIJgud$daOKQkZIOqfgJzGVKdy7viHaVX498E80u1V0ko9nL7g=', '2024-07-26 04:54:35.696051', 0, 'lalala366', '', '', 'lalala36@denv.com', 0, 1, '2024-07-26 04:13:26.725116'),
(11, 'pbkdf2_sha256$720000$hVrOb6q0JaIMsT200Dlp48$ihZd52VoFhSUBtB1vR23UABmT0BGnlg4svm2nQ/TfjQ=', '2024-07-26 17:11:34.258611', 0, 'RafaelaZulu', '', '', 'rafaelazulu@err.com.pt', 0, 1, '2024-07-26 16:51:01.080545'),
(12, 'pbkdf2_sha256$720000$i0SKo8PWaBuVQIAPvUpWYF$VtNj53Nl6tpGHQdq+m26B5tn/OXV+Ibvql7XemNByj8=', NULL, 0, 'RafaelaZulu2', '', '', 'RafaelaZulu@rafaelazulu.com', 0, 1, '2024-07-26 17:41:02.197336'),
(13, 'pbkdf2_sha256$720000$OorCJdYpY9KvTS7ph9rMGv$N9aNWsKkQ1A8EetLtpyNzme6SmZeLXqfHNZ8tIZkZWc=', NULL, 0, 'RafaelaZulu22', '', '', 'RafaelaZulu2@rafaelazulu2.com', 0, 1, '2024-07-26 17:43:00.861704'),
(14, 'pbkdf2_sha256$720000$h05FHH9MeMUkiCEI2yJt8m$UwIYRom2gXtOnsHursgkV/STOwLdz3TVif/VuMzwYZ4=', '2024-07-29 00:00:37.290061', 0, 'RafaelaZulu25', '', '', 'RafaelaZulu25@rafaelazulu25.com', 0, 1, '2024-07-26 17:49:23.387059'),
(15, 'pbkdf2_sha256$720000$KW0bVcJPn2pbUm50qqTLdI$7ld1S2gAbPZhBoTGxAziwqwlDg34J9dasbJZYoWxTWc=', NULL, 0, 'RafaelaZulu28', '', '', 'RafaelaZulu28@rafaelazulu25.dc', 0, 1, '2024-07-26 17:55:25.323118'),
(16, 'pbkdf2_sha256$720000$pYpvDdlDQ58C1lMYfeA1Bm$QsEFAzRa0tqr/Mt9W9se/vSiIaZIoga/JnLv0yNPsGE=', NULL, 0, 'RafaelaZulu27', '', '', 'RafaelaZulu25@rafaelazulu25.com', 0, 1, '2024-07-26 18:03:47.324831'),
(17, 'pbkdf2_sha256$720000$JCo6B5tNSHNxGkP0g5FSt5$mFF7/j8/mfqf4Q+eV5Spp5jtWUNrwxRjN5XndLgDi7E=', '2024-07-26 18:40:47.726464', 0, 'RafaelaZulu251', '', '', 'RafaelaZulu251@denv.com', 0, 1, '2024-07-26 18:40:19.125071'),
(18, 'pbkdf2_sha256$720000$VxpzOeSAiGJN9x0C6mXSNs$y1Mhs/axiKFNxNq+lIpZZAtUxmj/bAQC3AOP0V4jd0c=', NULL, 0, 'lalala3666', '', '', 'lalala2@denv.com', 0, 1, '2024-07-26 18:44:12.064286'),
(19, 'pbkdf2_sha256$720000$KqG09kB4p63fwRQRUXMQeO$K2Lxo8oWZkrgejPwSWnmhWJuzWMAlOPhaCmwPEUIIus=', NULL, 0, 'RafaelaZulu2534', '', '', 'Rafael.caZulu25@rafaelazulu25.com', 0, 1, '2024-07-26 18:51:28.338733'),
(20, 'pbkdf2_sha256$720000$7Q8PgFui4rkBoGLiFWFY6G$yVakfW4i9yso4/WggUDJu+gViytqexsJgxzMAAhldr8=', NULL, 0, 'werders', '', '', 'werd@werders.comers', 0, 1, '2024-07-26 18:54:29.640109'),
(21, 'pbkdf2_sha256$720000$lQO5TU5aeIDdke8aDzqwzO$Xg0BCBVTBVSfJeJ9IJUSXCAu+b2z3xYifFWrbD+eNl4=', NULL, 0, 'RafaelaZulu25q', '', '', 'RafaelaZulu25q@rafaelazulu25.com', 0, 1, '2024-07-26 19:12:55.327136'),
(22, 'pbkdf2_sha256$720000$m1ULsPxXjkeNuExuFfeQCM$6BoXQeGye9Zyc9E42zShvbc+uSqjcPGE5Ytg0lSyo1o=', NULL, 0, 'RafaelaZulu25RafaelaZulu25', '', '', 'RafaelaZu@rafaelazulu25rafaelazulu25.com', 0, 1, '2024-07-26 19:26:02.352068'),
(23, 'pbkdf2_sha256$720000$5pxvL1Mj9kFODMfWGdXprB$1p4kvQp0zoT8NVQIJ0bZDkbEpTtbAjQa9O22OkiXoyM=', '2024-07-26 19:44:38.669234', 0, 'RafaelaZulu25qtt', '', '', 'RafaelaZulu25q@rafaelazulu25.com', 0, 1, '2024-07-26 19:30:10.789901'),
(24, 'pbkdf2_sha256$720000$tLwPlMVmKewQv7hNTeHT3L$thF8UiWIi+p1D5vTP/JNxvAY1QhXbbtCgcFzD1kWNZs=', NULL, 0, 'RafaelaZulu256666', '', '', 'RafaelaZulu25@rafaelazulu25.com', 0, 1, '2024-07-27 14:56:17.281896');

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'main', 'cadastro'),
(8, 'main', 'filme'),
(11, 'main', 'perfil'),
(9, 'main', 'profile'),
(10, 'main', 'userfilme'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Estrutura para tabela `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-07-23 21:15:48.066378'),
(2, 'auth', '0001_initial', '2024-07-23 21:15:48.530636'),
(3, 'admin', '0001_initial', '2024-07-23 21:15:48.649770'),
(4, 'admin', '0002_logentry_remove_auto_add', '2024-07-23 21:15:48.655667'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-07-23 21:15:48.663127'),
(6, 'contenttypes', '0002_remove_content_type_name', '2024-07-23 21:15:48.743361'),
(7, 'auth', '0002_alter_permission_name_max_length', '2024-07-23 21:15:48.802971'),
(8, 'auth', '0003_alter_user_email_max_length', '2024-07-23 21:15:48.818061'),
(9, 'auth', '0004_alter_user_username_opts', '2024-07-23 21:15:48.827054'),
(10, 'auth', '0005_alter_user_last_login_null', '2024-07-23 21:15:48.877762'),
(11, 'auth', '0006_require_contenttypes_0002', '2024-07-23 21:15:48.881734'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2024-07-23 21:15:48.888748'),
(13, 'auth', '0008_alter_user_username_max_length', '2024-07-23 21:15:48.900737'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2024-07-23 21:15:48.917855'),
(15, 'auth', '0010_alter_group_name_max_length', '2024-07-23 21:15:48.945776'),
(16, 'auth', '0011_update_proxy_permissions', '2024-07-23 21:15:48.955775'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2024-07-23 21:15:48.969409'),
(18, 'main', '0001_initial', '2024-07-23 21:15:48.986013'),
(19, 'main', '0002_cadastro_filme_profile_userfilme_and_more', '2024-07-23 21:15:49.303998'),
(20, 'sessions', '0001_initial', '2024-07-23 21:15:49.340910'),
(21, 'main', '0003_cadastro_filme_filme_diretor_filme_sinopse', '2024-07-24 19:31:17.245581'),
(22, 'main', '0004_perfil', '2024-07-25 19:26:00.796963'),
(23, 'main', '0005_alter_perfil_filmes_favoritos', '2024-07-26 01:59:33.441686'),
(24, 'main', '0006_alter_perfil_filmes_favoritos', '2024-07-26 01:59:33.454357');

-- --------------------------------------------------------

--
-- Estrutura para tabela `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('14ods7ckk0wupuhcaofnyhi8plthcrlk', '.eJxVjEEOwiAQRe_C2hAKtCMu3fcMZGaYStVAUtqV8e7apAvd_vfef6mI25rj1mSJc1IX5dXpdyPkh5QdpDuWW9Vcy7rMpHdFH7TpsSZ5Xg_37yBjy986yECSaBJCx2gGZPATOhuC4TMa15FlmGzvDA4G2HiA5KDrqZMEtrfq_QERXjga:1sWgLl:VCFf5z7dChBec1eaRsea_fZnyjEY6Ht_MLDzRtpThEk', '2024-07-24 18:34:29.093001'),
('1l0ouv4xwj3p2lsglf0bocohr5lckgwe', '.eJxVjEEOwiAQRe_C2pBCCzgu3fcMZGaYStVAUtqV8e7apAvd_vfef6mI25rj1mSJc1IXZdTpdyPkh5QdpDuWW9Vcy7rMpHdFH7TpsSZ5Xg_37yBjy9-amcR2dphCQgrkITkGL9Z0PZDpLU0I7H3gHtGkgb0RhwJn5xxCYFDvDwEbOGU:1sX4Oc:aoLiBSBkL6_LrjIxpTDjNLuMXeL_WPVouy2l6Dwh1pI', '2024-07-25 20:15:02.438672'),
('5h6kl7ina9324hr4c98nur8pe3faxlnn', '.eJxVjEEOwiAQRe_C2pBCCzgu3fcMZGaYStVAUtqV8e7apAvd_vfef6mI25rj1mSJc1IXZdTpdyPkh5QdpDuWW9Vcy7rMpHdFH7TpsSZ5Xg_37yBjy9-amcR2dphCQgrkITkGL9Z0PZDpLU0I7H3gHtGkgb0RhwJn5xxCYFDvDwEbOGU:1sXAJQ:CpooUNr0z0cxjHqwvS2THA0KoWjPkRvJwGpTJUR--nk', '2024-07-26 02:34:04.574375'),
('5p4x4fw6fp1c5ku9kgskew3u4ihe1ex3', '.eJxVjEEOwiAQRe_C2hAoFhiX7nsGMgyMVA0kpV0Z765NutDtf-_9lwi4rSVsPS9hTuIinDj9bhHpkesO0h3rrUlqdV3mKHdFHrTLqaX8vB7u30HBXr61TXaw5wEhOcXAxJ6iMxY8eh0Nk7KeWZNJLlIGAwQjxOwVKpNHYi3eH_VzOIY:1sWkEO:8KOti3fjcR8--C381RTUnoSLhZY3wncTnTumuRLeS7w', '2024-07-24 22:43:08.260158'),
('6e0vall0tln3a2s5a8917t2own92dy07', 'e30:1sWh0D:QrFErjbPJ_rnIEY2wiZsVC5k4J2zOxLrC0YtojLgJY8', '2024-07-24 19:16:17.659223'),
('6y8qe8msyeq72bqvafzvk0zlq5lualdi', 'e30:1sWhlr:ZGz_H-9ekoPLvYfgxZTAAmjjHurBcoYuDWBZhjKYGRE', '2024-07-24 20:05:31.379222'),
('96bgqmegovlyd1lhysecdt46b4pj3yg0', 'e30:1sWe0p:BLCB0vjTEEy9bYOMzaDjwr0voJV2l2MSZzJuZI1bMoU', '2024-07-24 16:04:43.550599'),
('d7tyfu7d4qzaqha7ujemwhhwecpqxy7k', '.eJxVjEEOwiAQRe_C2hBHYAZcuvcMZGCoVA1NSrsy3l2bdKHb_977LxV5XWpce5njKOqsjDr8bonzo7QNyJ3bbdJ5ass8Jr0peqddXycpz8vu_h1U7vVbY6I8mKEUTh6DdUBiXRIp4CwdEYKxDEgnCcjGCycmQYIMDslLAPX-APAsN7Y:1sWwYR:VCCNTEU-Stagi6p84vIzhkg39iOr-MGJukwZBQHKo9w', '2024-07-25 11:52:39.915459'),
('ed6wdmgfq1l86b7tsret9x9zf5bmukpn', 'e30:1sWdrH:3m9L2LA0CoXB4DQQHti4Ub6CxOwptWlZcSbmJSzPVz4', '2024-07-24 15:54:51.971107'),
('f5z3ix1tpgwbntkzryb999l1cuztwae9', 'e30:1sWdke:1_mtaNIQRoaWgeFNqsVKzng0sPz0xU0-tMScMODBamw', '2024-07-24 15:48:00.089623'),
('gzt9bi8os8sy7wv8fmr1d5yl1a354vqj', '.eJxVjEEOwiAQRe_C2hAKtCMu3fcMZGaYStVAUtqV8e7apAvd_vfef6mI25rj1mSJc1IX5dXpdyPkh5QdpDuWW9Vcy7rMpHdFH7TpsSZ5Xg_37yBjy986yECSaBJCx2gGZPATOhuC4TMa15FlmGzvDA4G2HiA5KDrqZMEtrfq_QERXjga:1sWgqN:N_WiOBNxiToFxcdFe4AnMMpRVDC7B5BJZnvFfNpMlbY', '2024-07-24 19:06:07.728950'),
('j2w2jl7a0l5gtwp2fti276d8863uei6g', 'e30:1sWdqg:WjnediOry7FRl5ZtFpeOnJ3Y6hjzrcWMUkJpcU3-Hgo', '2024-07-24 15:54:14.567991'),
('jsviislh636brs9j1v3d88kk92kckaq6', 'e30:1sWdvC:ptaJqIAp7Xwp4qK3Gwk82UK-NRdfo_YmgqNFQ583bUU', '2024-07-24 15:58:54.958472'),
('mp8xejfeva2favl7kc0m7wmwx6ek48vh', '.eJxVjEEOwiAQRe_C2hBHYAZcuvcMZGCoVA1NSrsy3l2bdKHb_977LxV5XWpce5njKOqsjDr8bonzo7QNyJ3bbdJ5ass8Jr0peqddXycpz8vu_h1U7vVbY6I8mKEUTh6DdUBiXRIp4CwdEYKxDEgnCcjGCycmQYIMDslLAPX-APAsN7Y:1sWz0X:Nj40brw4YvCpG2RhJx58Bqc8WWE6Uz7_CLh-pKjSa18', '2024-07-25 14:29:49.780092'),
('n2pwhtt4j7wrhphlrk3couxg0h7ebtm1', 'e30:1sWhN0:kY8HVCLKS-sS7-2amGFEBZi0yDoQLe8ajfY7JOTgLtE', '2024-07-24 19:39:50.252298'),
('q1hb24su4mgkcv2qgga77ycvzllh6pw8', '.eJxVjEEOwiAQRe_C2hAoFhiX7nsGMgyMVA0kpV0Z765NutDtf-_9lwi4rSVsPS9hTuIinDj9bhHpkesO0h3rrUlqdV3mKHdFHrTLqaX8vB7u30HBXr61TXaw5wEhOcXAxJ6iMxY8eh0Nk7KeWZNJLlIGAwQjxOwVKpNHYi3eH_VzOIY:1sWjIu:o3b-4V3DksP-RFwbXFgl6sUlIyuPq7s-hgsD9lYweWk', '2024-07-24 21:43:44.065744'),
('sbrj5jvfj0rsrynyagqhd7pj9f5y79c9', '.eJxVjMEOwiAQRP-FsyELxcJ69O43kGUBqRpISnsy_rtt0oPeJvPezFt4Wpfi155mP0VxEQrE6bcMxM9UdxIfVO9NcqvLPAW5K_KgXd5aTK_r4f4dFOplWzPaQJjjkA2BNUxgkmONWsUtOMMII6iRAADRYBr4TAQaXLaJEFF8vgdoN6k:1sXD4h:XIn2BR7LC_47mjnpbnEmIrnFXhtGXPPMDrVOzFLS924', '2024-07-26 05:31:03.424848'),
('tdu97z9787st9h21uly9gceur2xwh6tw', 'e30:1sWioR:yzG-BnP9VJV8RO2dB0jp-B1hI7k_j1y1ZCdGyg8mcys', '2024-07-24 21:12:15.272581'),
('tpmhr46ma2n7uqu6c3c49k2h1dmyx04l', 'e30:1sWir7:yNY13iCx1prl3p6B1dcufg1rGUQ9YojeieGnaEG7LTw', '2024-07-24 21:15:01.723303'),
('y4zxvxyfwdge0wru7df9vx23o494pcj2', 'e30:1sWdsY:Xzum8rAhnU6Hj9kHBdMm9IcmO0cc1m4i4ermQwlX-M8', '2024-07-24 15:56:10.490033'),
('y5x39wdtyjmf4vct03dv1p1sp2ljun4u', '.eJxVjEEOwiAQRe_C2hBoKUxduvcMZDozSNVAUtqV8e7apAvd_vfef6mI25rj1mSJM6uzsk6dfscJ6SFlJ3zHcquaalmXedK7og_a9LWyPC-H-3eQseVvjTb0ozeGXYdI0IWRE7AXh8kmKxYCEKAjdgEA2PBgB-o8jUGcGNOr9wcFpjfi:1sY9oh:EX7Iv077nuE-ztaH_niytRqJ4z1GYF82JnLWyQK7Ak8', '2024-07-28 20:14:27.325019'),
('ys2d0ifvjc37pokoe9gbl4udmb6cewx5', 'e30:1sWdjo:kMdCR_AiMG8QKBKmrmlMfB6cfFzOA5VqqLN2YmOb2bE', '2024-07-24 15:47:08.251671');

-- --------------------------------------------------------

--
-- Estrutura para tabela `filmes_tarantino`
--

CREATE TABLE `filmes_tarantino` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `ano_lancamento` int(11) NOT NULL,
  `onde_assistir` varchar(255) NOT NULL,
  `elenco` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_cadastro`
--

CREATE TABLE `main_cadastro` (
  `id` bigint(20) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` longtext NOT NULL,
  `data_criacao` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filme_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `main_cadastro`
--

INSERT INTO `main_cadastro` (`id`, `titulo`, `descricao`, `data_criacao`, `user_id`, `filme_id`) VALUES
(1, 'zzzzzzzzzzz', 'Filme lançado em 2010', '2024-07-24 17:40:01.738523', 4, NULL),
(2, 'Pulp Fiction (bra: Pulp Fiction: Tempo de Violência[4]; prt: Pulp Fiction[5][6]) é um filme estaduni', 'Filme lançado em 1994', '2024-07-24 17:41:38.631240', 4, NULL),
(3, 'Ezequiel', 'Filme lançado em 1994', '2024-07-24 17:42:54.332983', 4, NULL),
(4, 'Ezequiel', 'Filme lançado em 1994', '2024-07-24 17:53:05.598739', 4, NULL),
(5, 'Jerome Charyn', 'Filme lançado em 2024', '2024-07-24 21:05:24.606091', 7, NULL),
(6, 'quintaaaaaaaaaaa', 'Filme lançado em 666666', '2024-07-24 21:34:01.820063', 3, NULL),
(8, '', '', '2024-07-25 14:25:10.264487', 9, 17),
(10, '', '', '2024-07-25 19:35:33.718632', 1, 19),
(12, '', '', '2024-07-26 04:54:55.256650', 10, 21),
(13, '', '', '2024-07-26 16:55:59.425410', 11, 22),
(14, '', '', '2024-07-26 16:57:33.664069', 11, 23),
(18, '', 'Filme lançado em 1992', '2024-07-27 13:18:02.136410', 14, 27),
(19, '', 'Filme lançado em 1994', '2024-07-27 13:23:33.388086', 14, 28),
(20, '', 'Filme lançado em 1998', '2024-07-27 13:25:05.781839', 14, 29),
(21, '', 'Filme lançado em 1998', '2024-07-27 13:29:26.150650', 14, 30),
(22, '', 'Filme lançado em 2004', '2024-07-27 13:32:13.247182', 14, 31);

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_filme`
--

CREATE TABLE `main_filme` (
  `id` bigint(20) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `ano_lancamento` int(11) NOT NULL,
  `onde_assistir` varchar(100) NOT NULL,
  `elenco` longtext NOT NULL,
  `diretor` varchar(100) NOT NULL,
  `sinopse` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `main_filme`
--

INSERT INTO `main_filme` (`id`, `nome`, `ano_lancamento`, `onde_assistir`, `elenco`, `diretor`, `sinopse`) VALUES
(3, 'aaa', 333, 'sss', 'sss', 'Desconhecido', 'Desconhecido'),
(4, 'aaa', 333, 'sss', 'sss', 'Desconhecido', 'Desconhecido'),
(5, 'aaa', 333, 'sss', 'prenda tudo isso e muito mais e desenvolva suas habilidades em Inteligência artificial!\r\n\r\nInscreva-se\r\nSuas aulas serão com profissionais de sucesso:\r\nYasmin Ali Yassine\r\nMartha Gabriel\r\nDenis Chamas\r\nAndré Gildin', 'Desconhecido', 'mais e desenvolva suas habilidades em Inteligência artificial!                aaaaaaaaaa\r\n\r\nIn'),
(6, '10 - À Prova de Morte (Death Proof)', 2009, 'Netflix', 'À Prova de Morte é um filme de 2007 que faz parte do projeto Grindhouse, uma homenagem aos filmes de exploitation dos anos 1970. Na história, acompanhamos um dublê perturbado que usa seu carro como uma arma mortal contra mulheres. O filme é conhecido por suas cenas de perseguição de carros intensas e estilo visual característico.', 'Desconhecido', 'ccccccccccccccccccccccccccccccccccccccccccccccccccccccc'),
(7, 'zzzzz', 2345, 'qqqqqqq', 'wwwwwwwwwwww', 'Desconhecido', 'Desconhecido'),
(8, 'aaaaa', 666666, 'net', 'u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`u{5I8WZ_[4h`', 'Desconhecido', 'Desconhecido'),
(9, 'aaaaa', 666666, 'net', 'gdgdggdgdgddgdgdgdg', 'Desconhecido', 'Desconhecido'),
(11, 'Pulp Fiction (bra: Pulp Fiction: Tempo de Violência[4]; prt: Pulp Fiction[5][6]) é um filme estaduni', 1994, 'Cinema', 'John Travolta\r\nSamuel L. Jackson\r\nUma Thurman\r\nHarvey Keitel\r\nTim Roth\r\nAmanda Plummer\r\nMaria de Medeiros\r\nVing Rhames\r\nEric Stoltz\r\nRosanna Arquette\r\nChristopher Walken\r\nBruce Willis', 'Desconhecido', 'Desconhecido'),
(12, 'Ezequiel', 1994, 'Cinema', 'Ezequiel 25:17\r\n\r\nA recitação pseudobíblica Ezequiel 25:17, proferida por Jules Winnfield (Samuel L. Jackson), foi eleita a quarta fala mais marcante da história do cinema.[71]\r\nÉ um ritual de Jules recitar o que ele chama de uma passagem bíblica, Ezequiel 25:17, antes de executar alguém. Escuta-se a passagem três vezes — em \"Prelúdio para \'Vincent Vega a esposa de Marsellus Wallace\'\", quando Jules e Vincent vão recuperar a maleta de Marsellus com Brett; a mesma recitação uma segunda vez, no começo de \"A Situação Bonnie\", que sobrepõe o final da sequência supracitada; e no Epílogo, na cena do café no restaurante. A primeira versão da passagem é a seguinte:[72]', 'Desconhecido', 'Desconhecido'),
(14, 'Jerome Charyn', 2024, 'Cinema oculto', 'Toda a carreira de Travolta se torna uma história de fundo, o mito da estrela do cinema que caiu em desgraça, mas ainda reside em nossa memória como o rei da discoteca. Nós ficamos esperando ele encolher a barriga, vestir uma roupa branca de poliéster e entrar no clube 2001 Odyssey em Bay Ridge, Brooklyn, onde ele dançará por nós e nunca, nunca parará. Daniel Day-Lewis não poderia despertar esse desejo em nós. Ele não é parte da cosmologia maluco da América […] Tony Manero [é] um anjo sentado no ombro de Vincent […] a dança [de Vincent e Mia] pode estar próxima da coreografia de Anna Karina com seus dois namorados gângsters em Band', 'Desconhecido', 'Desconhecido'),
(17, 'À Prova de Morte', 2010, 'Amazon Prime video', 'Kurt Russell, Rosario Dawson, Zoë Bel  16 de julho de 2010 No cinema | 1h 50min | Comédia, Drama, Suspense\r\nDireção: Quentin Tarantino | Roteiro Quentin Tarantino', 'Quentin Tarantino', 'Dublê Mike é um ex-profissional da indústria do cinema e da TV que gosta de levar mulheres para passeios mortais em seu tempo livre. Ele modificou seu carro para que o veículo seja à prova de morte para o motorista. Enquanto provoca acidentes e as vítimas se acumulam, ele se salva sem praticamente n'),
(19, 'Crítica | À Prova de Morte', 2014, 'Cinema vvvvvvvvvvv', 'Tive a oportunidade de assistir À Prova de Morte pela primeira vez ainda em seu lançamento original, no cinema, nos Estados Unidos, juntamente com Planeta Terror, de Robert Rodriguez. Os dois loucos diretores resolveram fazer uma dobradinha homenageando as sessões apelidadas de Grindhouse nos EUA, extremamente famosas por aquelas bandas lá pela década de 70: dois filmes B juntos, passando um depois do outro em uma sessão só. Enquanto Rodriguez,', 'Rodriguez vazque', 'Utilizamos cookies para tornar suas interações com nosso website mais relevantes. Eles nos ajudam a entender melhor como nossos websites são utilizados, para podermos adaptar o conteúdo para você. Para obter mais informações sobre os d'),
(21, 'quintaaaaaaaaaaa', 2020, 'net', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', 'Desconhecido', 'Desconhecido33333333333333333333333333'),
(22, 'Grindhouse', 2007, 'Youtubiu', 'Kurt RussellRose McGowanDanny Trejo NUNES', 'Robert Rodriguez', 'Uma experiência fracassada libera vírus que transforma humanos em zumbis sedentos de sangue e carnívoros. El Wray, Cherry, um médico e o xerife unem forças para sobreviver à noite, quando os mutantes ameaçam tomar a cidade e o mundo.'),
(23, 'Quentin Tarantino', 2007, 'Internet imdb', 'Direção: Quentin Tarantino | Roteiro Quentin Tarantino\r\nElenco: Kurt Russell, Rosario Dawson, Zoë Bell\r\nTítulo original Grindhouse: Death Proof', 'Desconhecido', 'Dublê Mike é um ex-profissional da indústria do cinema e da TV que gosta de levar mulheres para passeios mortais em seu tempo livre. Ele modificou seu carro para que o veículo seja à prova de morte para o motorista. Enquanto provoca acidentes e as vítimas se acumulam, ele se salva sem praticamente n'),
(27, 'Cães de Aluguel', 1992, 'ImDB autostarbokks movies', 'Chris Penn Nice Guy Eddie Cabot\r\nEdward Bunker Mr. Blue\r\nHarvey Keitel Mr. White\r\nLawrence Tierney Joe Cabot\r\nMichael Madsen (I) Mr. Blonde - Vic Vega', 'Quentin Tarantino', 'Em \"Cães de Aluguel\", o audacioso Debut de Quentin Tarantino, somos arrebatados para as sombrias vielas do crime e da traição, onde a lealdade é tão fluida quanto o sangue que mancha o chão. https://filmow.com/caes-de-aluguel-t4579/'),
(28, 'O Balé Brutal de \'Cães de Aluguel.', 1994, 'Linked cropet plataform video', 'Chris Penn Nice Guy Eddie Cabot\r\nEdward Bunker Mr. Blue\r\nHarvey Keitel Mr. White\r\nLawrence Tierney Joe Cabot\r\nMichael Madsen (I) Mr. Blonde - Vic Veg', 'Tarantino e Melany Gul', 'Realmente o profissional tinha razão no final, aquela sequência final, na minha opinião quem ficou mais devastado foi o Mister White, pequeno spoiler, sério ele foi o personagem que mais gostei, porém teve talvez o desfecho mais merda, olhando do ponto de vista dele.'),
(29, '\"Cães de Aluguel\", o audacioso debut de Quentin Tarantino', 1998, 'https://filmow.com/caes-de-aluguel-t4579/', 'Quanto a trama, aí é que esta, não achei que ela foi algo espetacular, apenas boa, tem a questão da expectativa alta sobre o diretor então esperava mais, porém o que não posso reclamar são os diálogos, a abertura do filme realmente é icônica, era uma conversa muito estupida e especifica porém crível, soa como algo natural em uma conversa bem privada com seus amigos onde idiotices são ditas e discutidas, dava para sentir que era uma conversa real entre conhecidos, tipo o Mister Pink, uma hora ele parecia um babaca e outra ele parecia ter razão sobre o argumento dele, essa cena é incrível.', 'Desconhecido', 'Quanto a trama, aí é que esta, não achei que ela foi algo espetacular, apenas boa, tem a questão da expectativa alta sobre o diretor então esperava mais, porém o que não posso reclamar são os diálogos, a abertura do filme realmente é icônica, era uma conversa muito estupida e especifica incrível. gg'),
(30, 'Joe Cabot (Lawrence Tierney)', 1998, 'https://filmow.com/caes-de-aluguel-t4579/', 'Excelente filme, ótimos atores, ótimos diálogos, um bom filme de ação que não precisa de nenhuma cena muito agitada cheia de efeitos e tiroteios. Boa opção', 'Desconhecido', 'Excelente filme, ótimos atores, ótimos diálogos, um bom filme de ação que não precisa de nenhuma cena muito agitada cheia de efeitos e tiroteios.'),
(31, 'Kill Bill - Volume 2', 2004, 'https://www.adorocinema.com/filmes/filme-53879/', 'Direção: Quentin Tarantino | Roteiro Quentin Tarantino, Uma Thurman\r\nElenco: Uma Thurman, David Carradine, Michael Madsen\r\nTítulo original Kill Bill: Volume 2', 'Desconhecido', 'Na verdade, apesar das centenas de referências que atestam a assinatura autoral de QT, Kill Bill: Vol. 2 é um filme mais normativo do que o Vol. 1; ele tem menos personagens, os banhos de sangue são mais contidos, há um retorno aos diálogos verborrágicos (embora menos fluentes) e a um arco narrativo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_perfil`
--

CREATE TABLE `main_perfil` (
  `id` bigint(20) NOT NULL,
  `bio` longtext NOT NULL,
  `data_nascimento` date DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `main_perfil`
--

INSERT INTO `main_perfil` (`id`, `bio`, `data_nascimento`, `user_id`) VALUES
(1, '', NULL, 1),
(2, '', NULL, 10),
(3, '', NULL, 11),
(4, '', NULL, 14);

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_perfil_filmes_favoritos`
--

CREATE TABLE `main_perfil_filmes_favoritos` (
  `id` bigint(20) NOT NULL,
  `perfil_id` bigint(20) NOT NULL,
  `filme_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_profile`
--

CREATE TABLE `main_profile` (
  `id` bigint(20) NOT NULL,
  `bio` longtext NOT NULL,
  `location` varchar(30) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `main_userfilme`
--

CREATE TABLE `main_userfilme` (
  `id` bigint(20) NOT NULL,
  `data_adicao` datetime(6) NOT NULL,
  `filme_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `user_filmes`
--

CREATE TABLE `user_filmes` (
  `usuario_id` int(11) NOT NULL,
  `filme_id` int(11) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Índices de tabela `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Índices de tabela `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Índices de tabela `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Índices de tabela `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Índices de tabela `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Índices de tabela `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Índices de tabela `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Índices de tabela `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Índices de tabela `filmes_tarantino`
--
ALTER TABLE `filmes_tarantino`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `main_cadastro`
--
ALTER TABLE `main_cadastro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `main_cadastro_user_id_eb411226_fk_auth_user_id` (`user_id`),
  ADD KEY `main_cadastro_filme_id_40d734e0_fk_main_filme_id` (`filme_id`);

--
-- Índices de tabela `main_filme`
--
ALTER TABLE `main_filme`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `main_perfil`
--
ALTER TABLE `main_perfil`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Índices de tabela `main_perfil_filmes_favoritos`
--
ALTER TABLE `main_perfil_filmes_favoritos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `main_perfil_filmes_favoritos_perfil_id_filme_id_c52ee561_uniq` (`perfil_id`,`filme_id`),
  ADD KEY `main_perfil_filmes_favoritos_filme_id_108fa157_fk_main_filme_id` (`filme_id`);

--
-- Índices de tabela `main_profile`
--
ALTER TABLE `main_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Índices de tabela `main_userfilme`
--
ALTER TABLE `main_userfilme`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `main_userfilme_user_id_filme_id_f806f979_uniq` (`user_id`,`filme_id`),
  ADD KEY `main_userfilme_filme_id_686e0b9a_fk_main_filme_id` (`filme_id`);

--
-- Índices de tabela `user_filmes`
--
ALTER TABLE `user_filmes`
  ADD PRIMARY KEY (`usuario_id`,`filme_id`),
  ADD KEY `filme_id` (`filme_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de tabela `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `filmes_tarantino`
--
ALTER TABLE `filmes_tarantino`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `main_cadastro`
--
ALTER TABLE `main_cadastro`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `main_filme`
--
ALTER TABLE `main_filme`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `main_perfil`
--
ALTER TABLE `main_perfil`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `main_perfil_filmes_favoritos`
--
ALTER TABLE `main_perfil_filmes_favoritos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `main_profile`
--
ALTER TABLE `main_profile`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `main_userfilme`
--
ALTER TABLE `main_userfilme`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Restrições para tabelas `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Restrições para tabelas `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `main_cadastro`
--
ALTER TABLE `main_cadastro`
  ADD CONSTRAINT `main_cadastro_filme_id_40d734e0_fk_main_filme_id` FOREIGN KEY (`filme_id`) REFERENCES `main_filme` (`id`),
  ADD CONSTRAINT `main_cadastro_user_id_eb411226_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `main_perfil`
--
ALTER TABLE `main_perfil`
  ADD CONSTRAINT `main_perfil_user_id_9aa8a2f6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `main_perfil_filmes_favoritos`
--
ALTER TABLE `main_perfil_filmes_favoritos`
  ADD CONSTRAINT `main_perfil_filmes_f_perfil_id_34df4f2e_fk_main_perf` FOREIGN KEY (`perfil_id`) REFERENCES `main_perfil` (`id`),
  ADD CONSTRAINT `main_perfil_filmes_favoritos_filme_id_108fa157_fk_main_filme_id` FOREIGN KEY (`filme_id`) REFERENCES `main_filme` (`id`);

--
-- Restrições para tabelas `main_profile`
--
ALTER TABLE `main_profile`
  ADD CONSTRAINT `main_profile_user_id_b40d720a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `main_userfilme`
--
ALTER TABLE `main_userfilme`
  ADD CONSTRAINT `main_userfilme_filme_id_686e0b9a_fk_main_filme_id` FOREIGN KEY (`filme_id`) REFERENCES `main_filme` (`id`),
  ADD CONSTRAINT `main_userfilme_user_id_8cacedbd_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Restrições para tabelas `user_filmes`
--
ALTER TABLE `user_filmes`
  ADD CONSTRAINT `user_filmes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_filmes_ibfk_2` FOREIGN KEY (`filme_id`) REFERENCES `filmes_tarantino` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
